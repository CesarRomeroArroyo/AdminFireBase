export interface MenuModel {
    icono: string;
    texto: string;
    link: string;
    estado: number;
}
