export interface UsuarioModel {
    nombre: string;
    user: string;
    password: string;
    email: string;
    estado: number;
}
