export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDMGYmZroI-5MvsXLdw2EgKElDU51RvfV8",
    authDomain: "admin-fb04f.firebaseapp.com",
    databaseURL: "https://admin-fb04f.firebaseio.com",
    projectId: "admin-fb04f",
    storageBucket: "admin-fb04f.appspot.com",
    messagingSenderId: "29233371076"
  }
};
